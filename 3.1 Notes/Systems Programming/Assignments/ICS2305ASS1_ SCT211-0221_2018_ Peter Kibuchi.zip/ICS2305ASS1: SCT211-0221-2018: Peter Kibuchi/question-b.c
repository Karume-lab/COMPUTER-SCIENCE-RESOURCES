// SCT211-0221/2018: Peter Kibuchi

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

int main() {
    // Find the process ID (PID) of the "NYONGA" shell script
    FILE *pidfile = popen("pgrep -o -f 'NYONGA.sh'", "r");
    if (pidfile == NULL) {
        perror("popen");
        exit(1);
    }

    char pid_str[16];
    if (fgets(pid_str, sizeof(pid_str), pidfile) != NULL) {
        // Convert the PID string to an integer
        int nyonga_pid = atoi(pid_str);

        // Kill the "NYONGA" shell script
        if (nyonga_pid > 0) {
            printf("Killing NYONGA (PID: %d)\n", nyonga_pid);
            kill(nyonga_pid, SIGTERM);
        } else {
            printf("NYONGA is not running.\n");
        }
    } else {
        printf("NYONGA is not running.\n");
    }

    pclose(pidfile);
    return 0;
}
