// SCT211-0221/2018: Peter Kibuchi

#include <stdio.h>

int main() {
    FILE *file = fopen("C:/JUJU.txt", "w");
    if (file) {
        fprintf(file, "This is the JUJU file.");
        fclose(file);
        printf("File 'JUJU.txt' created in C:/.\n");
    } else {
        printf("Failed to create the file.\n");
    }
    return 0;
}
