// SCT211-0221/2018: Peter Kibuchi

#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>

// Structure to hold CPU usage data
typedef struct {
    double usage;
} CPUData;

// Function to update CPU usage data
void update_cpu_data(CPUData *cpu_data) {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        // Calculate CPU usage as a percentage
        cpu_data->usage = 100.0 - (100.0 * info.loads[0] / info.procs);
    }
}

// Callback to draw the CPU usage graph
gboolean draw_cpu_graph(GtkWidget *widget, cairo_t *cr, gpointer data) {
    CPUData *cpu_data = (CPUData *)data;
    int width, height;
    gtk_widget_get_size_request(widget, &width, &height);

    // Draw the background
    cairo_set_source_rgb(cr, 0.9, 0.9, 0.9);
    cairo_rectangle(cr, 0, 0, width, height);
    cairo_fill(cr);

    // Draw the CPU usage graph
    cairo_set_source_rgb(cr, 0.0, 0.5, 0.0);
    cairo_set_line_width(cr, 2.0);
    cairo_move_to(cr, 0, height);
    cairo_line_to(cr, width * cpu_data->usage / 100.0, height);
    cairo_stroke(cr);

    return TRUE;
}

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *drawing_area;
    CPUData cpu_data;

    // Initialize GTK
    gtk_init(&argc, &argv);

    // Create the main window
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "CPU Usage Monitor");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 100);

    // Create a drawing area
    drawing_area = gtk_drawing_area_new();
    gtk_container_add(GTK_CONTAINER(window), drawing_area);

    // Connect the "draw" signal to the draw_cpu_graph function
    g_signal_connect(G_OBJECT(drawing_area), "draw", G_CALLBACK(draw_cpu_graph), &cpu_data);

    // Update the CPU usage data every second
    g_timeout_add(1000, (GSourceFunc)update_cpu_data, &cpu_data);

    // Show all widgets
    gtk_widget_show_all(window);

    // Start the GTK main loop
    gtk_main();

    return 0;
}
