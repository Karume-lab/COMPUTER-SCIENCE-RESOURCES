#!/bin/bash

# This is the NYONGA shell script.
# It will keep running as long as the shell is open.

echo "NYONGA shell script is running."

# Keep the script running indefinitely
while true; do
  sleep 1
done
