#!/bin/bash
echo "rm C:/JUJU.txt" | at now + 5 minutes
