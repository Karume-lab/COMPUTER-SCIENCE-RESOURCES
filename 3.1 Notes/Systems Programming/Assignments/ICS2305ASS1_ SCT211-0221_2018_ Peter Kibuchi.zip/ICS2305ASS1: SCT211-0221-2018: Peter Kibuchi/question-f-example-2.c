// SCT211-0221/2018: Peter Kibuchi

#include <stdio.h>
#include <signal.h>
#include <unistd.h>

// Handler function for SIGUSR2
void sigusr2_handler(int signum) {
    printf("Received SIGUSR2\n");
}

int main() {
    // Register the SIGUSR2 signal handler
    signal(SIGUSR2, sigusr2_handler);

    printf("Send a SIGUSR2 signal to this process using 'kill -SIGUSR2 <pid>'\n");

    // Send a SIGUSR2 signal to the current process
    raise(SIGUSR2);

    return 0;
}
