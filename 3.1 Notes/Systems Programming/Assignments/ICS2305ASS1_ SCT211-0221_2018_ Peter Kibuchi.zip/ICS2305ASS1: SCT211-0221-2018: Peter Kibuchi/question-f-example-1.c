// SCT211-0221/2018: Peter Kibuchi

#include <stdio.h>
#include <signal.h>
#include <unistd.h>

// Handler function for SIGUSR1
void sigusr1_handler(int signum) {
    printf("Received SIGUSR1\n");
}

int main() {
    // Register the SIGUSR1 signal handler
    signal(SIGUSR1, sigusr1_handler);

    printf("Send a SIGUSR1 signal to this process using 'kill -SIGUSR1 <pid>'\n");

    // Keep the process running
    while (1) {
        sleep(1);
    }

    return 0;
}
