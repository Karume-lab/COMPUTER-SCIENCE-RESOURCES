// SCT211-0221/2018: Peter Kibuchi

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    // Open a pipe to execute the "ps" command and read its output
    FILE *pipe = popen("ps -e -o pid,pri,ppid", "r");
    if (!pipe) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Print the header
    printf("PID\tPriority\tParent PID\n");

    // Read and print process information
    char line[256];
    while (fgets(line, sizeof(line), pipe)) {
        if (line[0] >= '0' && line[0] <= '9') {  // Check if the line starts with a digit (process ID)
            int pid, priority, ppid;
            if (sscanf(line, "%d %d %d", &pid, &priority, &ppid) == 3) {
                printf("%d\t%d\t\t%d\n", pid, priority, ppid);
            }
        }
    }

    // Close the pipe
    pclose(pipe);

    return 0;
}
