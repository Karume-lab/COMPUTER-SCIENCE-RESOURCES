# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

template="invitation_template.txt"
student_list="student_list.txt"

if [ ! -f "$template" ]; then
    echo "Error: Template file not found."
    exit 1
fi

if [ ! -f "$student_list" ]; then
    echo "Error: Student list file not found."
    exit 1
fi

while read -r line; do
    name=$(echo "$line" | cut -d ' ' -f 1)
    email=$(echo "$line" | cut -d ' ' -f 2)

    # Read the template and replace placeholders with student-specific information
    invitation_text=$(sed "s/%NAME%/$name/g" "$template")

    # Send the invitation email
    echo "$invitation_text" | mail -s "Invitation to 3rd Year Projects Webinar" "$email"

    echo "Invitation sent to $name ($email)"
done < "$student_list"
