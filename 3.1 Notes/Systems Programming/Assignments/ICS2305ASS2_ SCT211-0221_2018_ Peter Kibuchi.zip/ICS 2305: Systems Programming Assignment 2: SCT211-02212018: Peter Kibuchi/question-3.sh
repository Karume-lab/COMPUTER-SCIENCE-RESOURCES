# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <UID>"
    exit 1
fi

uid="$1"

# Use the last command to retrieve login history and filter it by UID
login_count=$(last | grep " $uid " | wc -l)

echo "User with UID $uid has logged in $login_count times."
