# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

read -p "Enter the directory path containing BMP files: " directory

if [ ! -d "$directory" ]; then
    echo "Error: '$directory' is not a valid directory."
    exit 1
fi

# Check if ImageMagick is installed
if ! command -v convert &> /dev/null; then
    echo "Error: ImageMagick is not installed. Please install it to use this script."
    exit 1
fi

# Convert BMP files to JPEG files
bmp_files=$(find "$directory" -type f -name "*.bmp")
converted_count=0

for bmp_file in $bmp_files; do
    jpeg_file="${bmp_file%.bmp}.jpeg"
    convert "$bmp_file" "$jpeg_file"
    converted_count=$((converted_count + 1))
done

echo "Converted $converted_count BMP files to JPEG."
