# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

directory="$1"

if [ ! -d "$directory" ]; then
    echo "Error: '$directory' is not a valid directory."
    exit 1
fi

empty_folders=0

find "$directory" -type d -empty | while read -r folder; do
    creation_time=$(stat -c "%y" "$folder")
    echo "Empty folder: $folder, Created on: $creation_time"
    empty_folders=$((empty_folders + 1))
done
