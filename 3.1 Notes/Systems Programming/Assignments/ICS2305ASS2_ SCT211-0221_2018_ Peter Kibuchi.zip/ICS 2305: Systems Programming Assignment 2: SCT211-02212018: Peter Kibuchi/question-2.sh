# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

# Check if the file exists
if [ -e "JUJAyetu.txt" ]; then
    # Use tr to remove whitespace characters and count the remaining characters
    char_count=$(cat JUJAyetu.txt | tr -d '[:space:]' | wc -m)
    
    echo "Number of characters (excluding white spaces) in JUJAyetu.txt: $char_count"
else
    echo "File 'JUJAyetu.txt' does not exist."
fi
