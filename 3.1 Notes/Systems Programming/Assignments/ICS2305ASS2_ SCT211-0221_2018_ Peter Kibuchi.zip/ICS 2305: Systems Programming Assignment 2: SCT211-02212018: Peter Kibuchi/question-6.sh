# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <IP_address>"
    exit 1
fi

ip_address="$1"

# Use nmap to scan the specified IP address
nmap -sn "$ip_address" | grep "Host is up" | cut -d " " -f 2
