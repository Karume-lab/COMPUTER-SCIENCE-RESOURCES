# SCT211-0221/2018: Peter Kibuchi

#!/bin/bash

sum=0  # Initialize the sum to 0

echo "Enter 5 numbers:"

# Loop to read 5 numbers
for ((i = 1; i <= 5; i++)); do
    read -p "Enter number $i: " num
    sum=$((sum + num))
done

echo "The sum of the 5 numbers is: $sum"
